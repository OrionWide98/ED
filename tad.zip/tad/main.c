#include <stdlib.h>
#include <stdio.h>
#include "ponto.h"

int main()
{
    Ponto* pA = cria(10,10);
    Ponto* pB = cria(20,20);

    float d = distancia(pA, pB);
    printf("Distancia entre A e B: %.2f\n", d);

    float x, y;

    acessa(pA, &x, &y);
    printf("Coordenadas ponto A: (%.2f,%.2f)\n", x,y);

    atribui(pB,10,50);

    d = distancia(pA,pB);
    printf("Distancia entre A e B: %.2f\n", d);

    libera(pA);
    libera(pB);
    return 0;
}
