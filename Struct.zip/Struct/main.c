#include <stdio.h>
#include <stdlib.h>
#include "ponto.c"

int main()
{
    Ponto *p1, *p2;
    float dist;

    p1 = cria(0,0);
    p2 = cria(10,10);

    dist = distancia(p1,p2);

    printf("Distancia = %.2f", dist);

    return 0;
}
