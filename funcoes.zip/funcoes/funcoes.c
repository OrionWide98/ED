#include <stdio.h>
#include "funcoes.h"
void boasVindas() {
    printf("Hello World!\n");
}

int soma (int a, int b) {
  int res;
  if(a<=0 || b<=0) return -1;
  res = a+b;
  return res;

}

//passagem de parametros por referencia
void troca (int * a, int * b) {
    int temp = *a;
    *a = *b;
    *b = temp;




}
