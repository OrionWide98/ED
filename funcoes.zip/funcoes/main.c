#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include "funcoes.h"




int main()
{

    setlocale(LC_ALL,"");
    int x=3;
    int y=5;
    int r;

    int * pX;  // ponteiro para x
    pX = &x;
    *pX = 6;

    printf("&X = %d\n", &x);
    printf("X = %d\n", x);

    troca (&x, &y);

    printf("pX = %d\n", pX);
    printf("X = %d\n", *pX);

    boasVindas();
    r = soma(x,y);
    if (r<0)
        printf ("Falha na opera��o de soma!\n");
    else
        printf("%d + %d = %d\n", x, y, r);
    return 0;
}





