#ifndef FUNCOES_H_INCLUDED
#define FUNCOES_H_INCLUDED

#include "funcoes.c"
void boasVindas();
int soma (int a, int b);
void troca (int * a, int * b);

#endif // FUNCOES_H_INCLUDED
