#ifndef FUNCOES_H_INCLUDED
#define FUNCOES_H_INCLUDED
#include "funcoes.c"

void ex1(int);
int ex2(int);
void ex3(int);
int ex4(int, int);
void ex5(int n);
int ex6(int, int);

#endif // FUNCOES_H_INCLUDED
