#include <stdio.h>
#include <stdlib.h>
#include "funcoes.h"

int main()
{
    int somap = 0;
    int a = 6;
    int s;
    ex1(a);
    s = ex2(a);
    printf("\nSoma = %d\n",s);
    ex3(a);

    s = ex4(5,3);
    printf("%d\n",s);
    ex5(a);
    printf("\n");
    somap = ex6(10,16);
    printf("\n%d",somap);
    return 0;
}
