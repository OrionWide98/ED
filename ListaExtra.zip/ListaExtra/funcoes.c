void ex1(int n){

    for (int i = 1;i<=n;i++){
        printf("%i ",i);
    }
}

int ex2(int b){
    int soma = 0;
    for (int i=1;i<=b;i++){
        soma += i;
    }
    return soma;
}

void ex3(int a){
    int b,c,i;
    int d = 0;
    i = b = c = 1;
    while(i<a){
        if (i==1) {
                printf("%d %d ",b,c);
        } else{
        d = b;
        b += c;
        c = d;
        printf("%d ",b);
        }
        i++;
    }
}

int ex4(int v1, int v2){
    int c;
    if(v1<v2){
        c = 1;
    }
    else if(v2<v1){
        c = -1;
    } else c = 0;

    return c;
}

void ex5(int n){
    float pol = 2.54;

    for(int i=0;i<=n;i++){
        printf("%d cm\t%5.2f polegadas\n",i, (i/pol));
    }
}

int ex6(int liI, int liS){
    int soma = 0;
    for(int i = liI;i<=liS;i++){
        printf("%d ",i);
        if(i%2==0){
            soma+=i;
        }
    }
    return soma;
}
