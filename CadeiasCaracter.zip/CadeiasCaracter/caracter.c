#include <stdio.h>

int isNumero(char c)
{
if ((c>='0')&&(c<='9'))
return 1;
else
return 0;
}

int isLetra(char c)
{
    if ((c >= 'a') && (c <= 'z') || (c >= 'A' && c <= 'Z'))
    return 1;
    else
    return 0;
}

char maiuscula(char c)
{
    if(c>= 'a' && c<='z')
    return c-32;
}

char * paraMin(char * c)
{
    for(int n=0; c[n] != '\0'; n++)
    {
        if(c[n] >= 65 && c[n] <= 90)
        c[n] += 32;
    }
    return c;
}

void main(int q, char ** v)
{
    char nome[50] = "";

    printf("Nome: ");
    //scanf("%s", nome);
    gets(nome);
    printf("Nome digitado: %s", nome);

    /*
    char ex[10];
    char pref[7] = "Aluno ";
    char nomeCompleto[50]="";
    strcpy(ex, "Francisco");
    strcat(nomeCompleto, pref);
    strcat(nomeCompleto, ex);
    printf("Nome: %s \n",ex);
    printf("Nome Completo: %s",paraMin(nomeCompleto));
    char c;
    printf("Digite um caractere:");
    scanf("%c",&c);
    printf("Maiuscula: %c\n",maiuscula(c));

    isNumero(c) == 1?printf("E um numero\n"):printf("Nao e numero\n");
    isLetra(c) == 1?printf("E letra\n"):printf("Nao e letra\n");
    */
}
