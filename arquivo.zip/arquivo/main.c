#include <stdio.h>
#include <stdlib.h>

int main()
{
    char v[1];
    int ** ambiente;
    FILE* fp;
    int filas, poltronas, nlinhas=0;
    char c;
    int fila=0;
    char s[1024];

    fp = fopen("SalaAloisio.csv", "rt");

    if(fp == NULL)
    {
        printf("Falha ao abrir arquivo de dados!\n\n");
        exit(0);
    }

    fscanf(fp, "%d;", &filas);
    fscanf(fp, "%d;", &poltronas);
    printf("Filas: %d\n",filas);
    printf("Poltronas: %d\n", poltronas);

    ambiente = (int **) malloc(filas * sizeof(int*));

    if(ambiente == NULL)
    {
        printf("Falha ao alocar memoria!\n\n");
        exit(1);
    }
    for(int n=0;n<filas;n++)
    {
        if(ambiente[n] == NULL)
        {
            printf("Falha ao alocar memoria!\n\n");
            exit(1);
        }
        ambiente[n] = (int *) malloc(poltronas * sizeof(int));
    }

    printf("\n==================================================\n");

    while ((fgets(s, 1024, fp)) != NULL)
    {
        for(int x=0;x<filas;x++)
        {
            for(int y=0;y<poltronas;y++)
            {
                sscanf(s, "%s;", &v);
                ambiente[x][y] = (int) v;
                //printf("%d", v);
                //ambiente[x][y] = v;
                //printf("%d ", ambiente[x][y]);
            }
        }
    }

    for(int i=0;i<filas;i++)
    {
        for(int a=0;a<poltronas;a++)
        {
            printf("%d ", ambiente[i][a]);
        }
        printf("\n");
    }

    printf("Numero de filas = %d\n\n",fila);

    fclose(fp);

/*
    fp = fopen("SalaAloisio.csv", "at");
    if(fp == NULL)
    {
        printf("Falha ao abrir arquivo de dados!\n\n");
        exit(0);
    }
    fprintf(stdout,"Numero de linhas = %d\n\n",nlinhas);
    fprintf(fp,"Numero de linhas = %d\n\n",nlinhas);
    */
    return 0;
}
