#include <stdio.h>
#include <stdlib.h>

// lista ser� uma sequencia de tipos structs
typedef struct media Media;

typedef struct media{
    int ra;
    float n1;
    float n2;
    Media * prox;
};

int main()
{
    Media * lista;
    lista = NULL;

    Media * novo;

    //cria um novo elemento
    novo = (Media*) malloc(sizeof(Media));
    if (novo == NULL){
        printf("Memoria insuficiente\n");
        exit(1);
    }

    novo-> ra = 1000;
    novo->n1 = 6.5;
    novo->n2 = 6.0;
    novo->prox = lista;

    //liga o onovo elemento na lista
    lista = novo;

    novo = (Media*) malloc(sizeof(Media));
    if (novo == NULL){
        printf("Memoria insuficiente\n");
        exit(1);
    }

    novo-> ra = 1001;
    novo->n1 = 9.5;
    novo->n2 = 7.0;
    novo->prox = lista;

    //liga o onovo elemento na lista
    lista = novo;

    novo = (Media*) malloc(sizeof(Media));
    if (novo == NULL){
        printf("Memoria insuficiente\n");
        exit(1);
    }

    novo-> ra = 1002;
    novo->n1 = 10.0;
    novo->n2 = 7.3;
    novo->prox = lista;

    //liga o onovo elemento na lista
    lista = novo;

    Media * ptr;

    for(ptr=lista; ptr!=NULL; ptr=ptr->prox)
    {
        printf("%d\t%5.2f\t%5.2f\n", ptr->ra, ptr->n1, ptr->n2);
    }

    return 0;
}
