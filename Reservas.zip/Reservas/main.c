#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE * fReserva;
    int filas, poltronas;
    char c;
    int nlinhas=0;
    char s[1024];

    fReserva = fopen("SalaAloisio.csv","rt");
    if(fReserva==NULL){
        printf("Falha ao abrir arquivo de dados!\n\n");
        exit(0);
    }


    fscanf(fReserva,"%d;",&filas);
    fscanf(fReserva,"%d;",&poltronas);
    printf("Filas : %d\n",filas);
    printf("Poltronas: %d\n\n",poltronas);

    while((fgets(s,1024,fReserva)) != NULL){

        nlinhas++;
        printf("%s",s);
    }
    fReserva = fopen("SalaAloisio.csv","at");
    if(fReserva==NULL){
        printf("Falha ao abrir arquivo de dados!\n\n");
        exit(0);
    }


    fprintf(fReserva,"Numero de linhas = %d\n\n",nlinhas);
    return 0;
}
