/*
* Lista Exercicios de Estrutura de Dados
*
* Clayton Gabriel Lorizolla RA: 18457
* Francisco Eduardo Pereira Sousa Silva RA: 18464
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Troca de Valores
void troca (int * a, int * b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Decremento e Incremento

void dec (int * a ,int* b) {
    --*a;
    ++*b;
}

// Perimetro e Area de um circulo

void circulo(float raio, float *peri, float *area) {
    *peri = 2 * 3.14 * raio;
    *area = 3.14 * pow(raio,2);
}

//Perimetro e Area de um quadrado

void quadrado (float lado, float* perimetro, float * area){
    *perimetro = lado*4;
    *area = pow(lado,2);
}

// Equa��o do segundo grau

void eq2grau(float a, float b, float c, float * x1, float * x2) {
    int delta = pow(b,2) - 4 * a * c;
    if (delta < 0){
        printf("Nao e possivel resolver, pois delta e negativo (%d)",delta);
    }
    else {
         *x1 = (-b + pow(delta,0.5))/(2 * a);
         *x2 = (-b - pow(delta,0.5))/(2 * a);
    }
}
