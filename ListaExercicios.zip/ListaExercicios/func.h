/*
* Lista Exercicios de Estrutura de Dados
*
* Clayton Gabriel Lorizolla RA: 18457
* Francisco Eduardo Pereira Sousa Silva RA: 18464
*/

#ifndef FUNC_H_INCLUDED
#define FUNC_H_INCLUDED
#include "func.c"

void troca(int * a, int * b);
void dec (int * a ,int* b);
void circulo(float raio, float *peri, float *area);
void quadrado (float lado, float* perimetro, float * area);
void eq2grau(float a, float b, float c, float * x1, float * x2);

#endif // FUNC_H_INCLUDED
