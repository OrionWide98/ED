#include <stdio.h>
#include <stdlib.h>
#include "func.h"

int main()
{
    float a=0, b=0, c=0,x1,x2;
    printf("Digite os valores para a,b e c da equacao do segundo grau\n");
    scanf("%f %f %f",&a,&b,&c);
    eq2grau(a,b,c,&x1,&x2);
    printf("As raizes sao\nx1= %.1f\nx2= %.1f",x1,x2);
}
