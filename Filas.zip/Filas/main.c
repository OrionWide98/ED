#include <stdio.h>
#include <stdlib.h>
#include "fila.c"

int main()
{
    Material * filaM = criaFilaM();
    Espirito * filaE = criaFilaE();

    int op;
    int senhaM = 1;
    int senhaE = 1;
    int cont = 1;

    printf("\"1. Retirar Senha Para Obter Bencao Material\"\n\"2. Retirar Senha Para Obter Bencao Espiritual\"\n\"3. Conceder Bencao Material\"\n\"4. Conceder Bencao Espiritual\"\n\"5. Mostrar Lista Para Bencao Material\"\n\"6. Mostrar Lista Para Bencao Espiritual\"\n\"0. Fechar tenda dos milagres\"\n\n");

    while(cont){

        printf(">> ");
        scanf("%i", &op);
        printf("\n");
        switch(op)
        {
        case 1:
            insereMaterial(filaM, senhaM);
            printf("Novo elemento na Fila Material!\n");
            senhaM++;
            break;
        case 2:
            insereEspiritual(filaE, senhaE);
            senhaE++;
            break;
        case 3:
            printf("%i", filaM->ini);
            break;
        case 4:
            printf("Quarta Opcao");
            break;
        case 5:
            printf("Quinta Opcao");
            break;
        case 6:
            printf("Sexta Opcao");
            break;
        case 0:
            printf("Encerrando o programa");
            exit(0);
        default:
            printf("Opcao invalida");
        }
    }
    return 0;
}
