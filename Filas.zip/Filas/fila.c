#include <stdlib.h>
#include "fila.h"

typedef struct filaM{
    Senha * ini;
    Senha * fim;
};

typedef struct filaE{
    Senha * ini;
    Senha * fim;
};

typedef struct no {
    int num;
    Senha* prox;
};

// funcoes para criar as filas Material e Espiritual.
Material* criaFilaM(){
    Material* f = (Material*) malloc(sizeof(Material));
    f->ini = f->fim = NULL;
    return f;
}

Espirito* criaFilaE(){
    Espirito* f = (Espirito*) malloc(sizeof(Espirito));
    f->ini = f->fim = NULL;
    return f;
}

Senha* ins_fim(Senha* fim, int v)
{
    Senha* p = (Senha*) malloc(sizeof(Senha));
    p->num = v;
    p->prox = NULL;
    if (fim != NULL) /* verifica se lista n�o estava vazia */
        fim->prox = p;
    return p;
}

void insereMaterial (Material* f, int v){
    f->fim = ins_fim(f->fim,v);
    if (f->ini==NULL) /* fila antes vazia? */
        f->ini = f->fim;
}

void insereEspiritual(Espirito* f, int v){
    f->fim = ins_fim(f->fim,v);
    if (f->ini==NULL) /* fila antes vazia? */
        f->ini = f->fim;
}
