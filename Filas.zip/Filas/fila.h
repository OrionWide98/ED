#ifndef FILA_H_INCLUDED
#define FILA_H_INCLUDED

typedef struct filaM Material;
typedef struct filaE Espirito;
typedef struct no Senha;
Material* criaFilaM ();
Espirito* criaFilaE ();
void insereMaterial (Material* f, int v);
void insereEspiritual(Espirito* f, int v);

#endif // FILA_H_INCLUDED
