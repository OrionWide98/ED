#include <stdio.h>
#include <stdlib.h>
#include "matriz.h"

int main()
{
    int a[2][2] = {{5, 4}, {3, 2}};
    int b[2][2] = {{5, 6}, {7, 8}};
    int c[2][2] = {0};

    soma_matriz_int(a, b, c, 2, 2);

    for(int k=0;k<2;k++)
    {
        for(int q=0;q<2;q++)
        {
            printf("%d ", c[k][q]);
        }
        printf("\n");
    }

    return 0;
}
