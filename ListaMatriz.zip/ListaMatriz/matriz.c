void soma_matriz_int(int **a, int **b, int **c, int lin, int col)
{
    int n1, n2;
    for(int k=0;k<(lin*col);k++)
    {
        n1 = a[k];
        n2 = b[k];
        c[k] = n1 + n2;
    }
}

void produto_matriz_int(int **a, int **b, int **c, int lin1, int col1,int lin2, int col2)
{
    if(col1 == lin2)
    {

        acumula = 0;

    }
    else printf("Nao e possivel fazer a multiplicacao");
}
