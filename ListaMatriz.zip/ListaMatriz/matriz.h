#ifndef MATRIZ_H_INCLUDED
#define MATRIZ_H_INCLUDED
#include "matriz.c"

void soma_matriz_int(int **a, int **b, int **c, int lin, int col);
void produto_matriz_int(int **a, int **b, int **c, int lin1, int col1,int lin2, int col2);

#endif // MATRIZ_H_INCLUDED
