#include "lista.h"
#include <stdio.h>

typedef struct no
{
    float x;
    float y;
    struct no * proximo;
};

No * inicializa()
{
    return NULL;
}

No * insereNo(No * l, float x, float y)
{
    No * novo;
    novo = (No *) malloc(sizeof(No));
    if (novo != NULL)
    {
        novo->x = x;
        novo->y = y;
        novo->proximo = l;
        l = novo;
    } else{
        printf("Erro na alocacao");
    }
    return novo;
}

void imprimeLista(No * l)
{

    for(l ; l!= NULL; l = l->proximo)
    {

    }
}
