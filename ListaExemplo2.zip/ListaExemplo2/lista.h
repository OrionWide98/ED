#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

typedef struct no No;

No * inicializa();
No * insereNo(No * l, float x, float y);
void imprimeLista(No * l)

#endif // LISTA_H_INCLUDED
