#include <stdio.h>
#include <stdlib.h>
#include "lista.c"

int main()
{
    No * lista;

    lista = inicializa();
    lista = insereNo(lista, 10, 13.75);
    lista = insereNo(lista, 21.5, 35);

    printf("Hello world!\n");
    return 0;
}
