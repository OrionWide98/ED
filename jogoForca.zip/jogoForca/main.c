#include <stdio.h>
#include <stdlib.h>
#include<time.h>
#include <string.h>

//Vari�veis globais
typedef struct word S;
typedef struct escolhida E;
int c;
int termos = 0;
char* pontC;
char linha[25];
char palavra[25];
char dica[25];
//char pEscolhida[25];
S* lista;
FILE* arquivo;
int* ordem;
int numEscolhido = 0;

//Vari�veis de jogo
char palavraEscolhida[25];
char dicaE[25];

typedef struct word{
    char chave[25];
    char dica[25];
    int sequencia;
    int usada;
    S* proximo;
};

typedef struct escolhida{
    char letra;
    int descoberta; // 0-nao foi descoberta | 1-foi descoberta
    E* proximo;
};

S* cria(){
    return NULL;
}

E* criaE(){
    return NULL;
}

S* inserePalavra(S* l, char chave[25], char dica[25]){
    S* novo;
    novo = (S*) malloc(sizeof(S));
    strcpy(novo->chave, chave);
    strcpy(novo->dica, dica);
    novo->usada = 0;
    novo->proximo = l;
    l = novo;
    termos++;
    return l;
}

void escreve(S* l){
    S* p;
    for(p = l;p!=NULL;p=p->proximo){
        printf("%s %s\n", p->chave,p->dica);
    }
}

void escreveE(E* l){
    E* p;
    for(p = l;p!=NULL;p=p->proximo){
        printf("%c", p->letra);
    }
}

void carregaJogo(){
    while((c = fgetc(arquivo)) != EOF){
        pontC = &palavra;
        int p = 0;
        fscanf(arquivo, "%s", &linha);
        for(int k=0;k<strlen(linha); k++){
            if(linha[k] == '\n'){
                pontC[p] = '\0';
                continue;
            }

            if(linha[k] == ';'){
                pontC[p] = '\0';
                pontC = &dica;
                p=0;
                continue;
            }
            else{
                pontC[p] = linha[k];
            }

            p++;
        }
        lista = inserePalavra(lista, palavra, dica);
        escolhePalavra(lista);
    }
}

void escolhePalavra(S* lista){
    //defineSequencia(lista);
    palavra[0] = '\0';

    for(S* p=lista;p!=NULL;p=p->proximo){
        if(p->sequencia == numEscolhido && p->usada == 0){
            strcpy(palavra, p->chave);
            strcpy(dica, p->dica);
            p->usada = 1;
            numEscolhido++;
            break;
        }
    }
}

void defineSequencia(S* l){
    ordem = (int*) malloc(termos * sizeof(int));
    for(int i= 0;i<termos;i++){
        ordem[i] = i;
    }

    for(int i=0;i<termos;i++)
	{
	    srand(rand());
		int r = rand() % termos;
		int temp = ordem[i];
		ordem[i] = ordem[r];
		ordem[r] = temp;
	}

    criaSequencia(l);
}

void criaSequencia(S* l){
    int k = 0;
    for(S* p=l;p!=NULL;p=p->proximo){
        p->sequencia = ordem[k];
        k++;
    }
}

E* insereLetra(E* l, char c){
    E* novo;
    novo = (E*) malloc(sizeof(E));
    novo->letra = c;
    novo->descoberta = 0;
    novo->proximo = l;
    l = novo;
    return l;
}

E* inverteP(E* l){
    E* temp = criaE();
    for(E* p=l;p!=NULL;p=p->proximo){
        E* novo;
        novo = (E*) malloc(sizeof(E));
        novo->letra = p->letra;
        novo->proximo = temp;
        temp = novo;
    }

    return temp;
}

E* transformaPalavraEmLista(E* l){
    for(int a=0;a<strlen(palavra); a++){
        l = insereLetra(l, palavra[a]);
    }

    l = inverteP(l);
    return l;
}

void escreveP(E* l){
    for(E* p=l;p!=NULL;p=p->proximo){
        printf("%c", p->letra);
    }
}

int verificarPalavra(E* l, char r){
    int acertou = 0;
    for(E* p=l;p!=NULL;p=p->proximo){
        if(p->letra == r){
            p->descoberta = 1;
            acertou = 1;
        }
    }
    return acertou;
}

void escreveForca(E* l){
    for(E* p=l;p!=NULL;p=p->proximo){
        if(p->descoberta == 1)
            printf("%c ", p->letra);
        else
            printf("_ ");
    }
}

int acertouPalavra(E* l){
    int qnt = 0, desc = 0;
    for(E* p =l; p!=NULL;p=p->proximo){
        qnt++;
        if(p->descoberta == 1)
            desc++;
    }

    if(qnt == desc)
        return 0;
    return 1;
}

void libera(E* l)
{
    E* p = l;
    while (p != NULL) {
        E* t = p->proximo;
        free(p);
        p = t;
    }
}

int main(int argc, char * arg[])
{
    char nomeArquivo[255];

    if(argc>1){
        strcpy(nomeArquivo, arg[1]);
    }

    srand(time(NULL));
    int op = 0;
    int tents = 0;
    int controle, completou = 0;
    char palpite;
    lista = cria();
    E* palavraEscolhida;
    palavraEscolhida = criaE();

    arquivo = fopen(nomeArquivo, "rt");
    if(arquivo == NULL){
        printf("Falha ao abrir o arquivo!");
        exit(1);
    }
    carregaJogo();
    defineSequencia(lista);
    escolhePalavra(lista);
    palavraEscolhida = transformaPalavraEmLista(palavraEscolhida);

    while(op == 0){
        escreveForca(palavraEscolhida);
        printf("\n");
        printf("Dica: %s\n", dica);
        printf("Tentativas Restantes: %i\n", 5-tents);
        printf("Digite um palpite: ");
        scanf("%c", &palpite);
        setbuf(stdin, NULL);
        controle = verificarPalavra(palavraEscolhida, palpite);
        completou = acertouPalavra(palavraEscolhida);
        system("cls");
        if(completou == 0){

            setbuf(stdin, NULL);
            escreveForca(palavraEscolhida);
            printf("\nParabens, voce acertou minha palavra!");
            system("pause");
            system("cls");
            tents = 0;
            escolhePalavra(lista);
            libera(palavraEscolhida);
            free(palavraEscolhida);
            palavraEscolhida = criaE();
            palavraEscolhida = transformaPalavraEmLista(palavraEscolhida);
            continue;
        }
        if(controle == 0)
            tents++;
        if(tents == 5){
            op = 1;
        }
    }

    printf("Voce nao adivinhou.A palavra era %s", palavra);
    //escreveP(palavraEscolhida);
    //escreve(lista);
    fclose(arquivo);

    return 0;
}
