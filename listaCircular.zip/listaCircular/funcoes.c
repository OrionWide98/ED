/*
Clayton Gabriel Lorizolla   RA: 18457
Francisco Eduardo Pereira Sousa Silva   RA: 18464
*/

typedef struct cidade Cidade;

typedef struct cidade{
    char nome[30];
    int coordX;
    int coordY;
    Cidade* proximo;
};

void inser_circular(Cidade** mapa, char nome[30], int cX, int cY)
{
    Cidade* novo;
    novo = (Cidade*) malloc(sizeof(Cidade));
    int p = 0;
    strcpy(novo->nome, nome);
    novo->coordX = cX;
    novo->coordY = cY;

    if(*mapa == NULL){
        novo->proximo = novo;
    }else{
        novo->proximo = (*mapa)->proximo;
        (*mapa)->proximo = novo;
    }
    *mapa = novo;
}

void imprime_lista(Cidade* lista){
    Cidade *aux = lista->proximo;

    do {
        //Calcular a dist�ncia

        printf("%s ", aux->nome);
        printf("(%i, %i)\n", aux->coordX, aux->coordY);
        aux = aux->proximo;
    }while (aux != lista->proximo);
    printf("\n");
}

float calcula_distancia(int x1, int y1, int x2, int y2){
    float dist;

    dist = pow((x1-x2), 2) + pow((y1-y2), 2);
    dist = sqrt(dist);

    return dist;
}

void imprime_distancias(Cidade* mapa){
    Cidade *aux = mapa->proximo;
    float distT = 0;
    float d;

    do{
        int x1 = aux->coordX;
        int y1 = aux->coordY;
        printf("%s\t\ta", aux->nome);
        aux = aux->proximo;
        int x2 = aux->coordX;
        int y2 = aux->coordY;
        d = calcula_distancia(x1,y1,x2,y2);
        distT += d;
        printf("\t%s\t=\t%.2f\n", aux->nome, d);
    }
    while(aux != mapa->proximo);
    printf("\nDistancia Total = %.2f\n", distT);
}
