/*
Clayton Gabriel Lorizolla   RA: 18457
Francisco Eduardo Pereira Sousa Silva   RA: 18464
*/

#ifndef FUNCOES_H_INCLUDED
#define FUNCOES_H_INCLUDED

void inser_circular(Cidade** mapa, char nome[30], int cX, int cY);
void imprime_lista(Cidade* lista);
float calcula_distancia(int x1, int y1, int x2, int y2);
void imprime_distancias(Cidade* mapa);

#endif // FUNCOES_H_INCLUDED
