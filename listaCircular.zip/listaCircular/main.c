/*
Clayton Gabriel Lorizolla   RA: 18457
Francisco Eduardo Pereira Sousa Silva   RA: 18464
*/

#include <stdio.h>
#include <stdlib.h>
#include "funcoes.c"

int main()
{
    Cidade* mapa = NULL;

    inser_circular(&mapa, "Cidade Um", 2,2);
    inser_circular(&mapa, "Cidade Dois", 10,4);
    inser_circular(&mapa, "Cidade Tres", 19,8);
    inser_circular(&mapa, "Cidade Quatro", 16,15);
    inser_circular(&mapa, "Cidade Cinco", 5,19);
    inser_circular(&mapa, "Cidade Seis", 8,10);

    imprime_lista(mapa);

    imprime_distancias(mapa);

    return 0;
}
