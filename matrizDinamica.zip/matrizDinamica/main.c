#include <stdio.h>
#include <stdlib.h>

int main()
{
    int **sala;
    int fila,pos;
    int linhas=10;
    int colunas=10;

    sala = (int **) malloc(linhas*sizeof(int*));
    for(int lin=0;lin<linhas;lin++)
    {
        sala[lin] = (int*) malloc(colunas * sizeof(int));
    }

    for(int l=0; l<linhas;l++)
        for(int c=0;c<colunas;c++)
            sala[l][c] = 0;

    do
    {
        system("cls");
        printf("Fileira : ");
        scanf("%d", &fila);
        if(fila<0) break;
        printf("Posicao : ");
        scanf("%d", &pos);
        if(pos<0) break;
        //Checa disponibilidade ou reservar(caso esteja disponivel)
        if(sala[fila][pos] == 0)
        {
            sala[fila][pos] = 1;
            printf("Reserva efetuada com sucesso! \n\n");
            system("pause");
        }
        else
        {
            printf("Maquina indisponivel!\n");
            system("pause");
        }
    }
    while(fila>=0);

    system("cls");

    for(int l=0; l<linhas;l++)
    {
        for(int c=0;c<colunas;c++)
            printf("%d | ", sala[l][c]);
        printf("\n");
    }

    return 0;
}
