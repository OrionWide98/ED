#include <stdio.h>
#include <stdlib.h>

#include"vetores.h"

int main()
{
   int v1[] = {2,3,4,5};
   int v2[] = {3,4,10,46};
   int maior=0;
   int menor=0;
   printf("1) Produto escalar = %d\n", escalar(v1,v2,4));
   printf("2) Todos diferentes = %d\n", todosDiferentes(v1,4)?"Sim":"Nao");
   printf("3)\n\tVetor atual:");
   impVetorInt(v1,4);
   rotaciona(v1,4);
   printf("\n\tVetor rotacionado: ");
   impVetorInt(v1,4);
   printf("\n");
   printf("4) Vetor2 = ");
   impVetorInt(v2,4);
   printf("\n\t Valores entre 4 e 10 = %d\n", contaValores(v2,4,4,10));
   printf("5)Menor valor do vetor 2 = %d \n", menorElemento(v2,4));
   printf("6)Maior valor do vetor 2 = %d \n", maiorElemento(v2,4));
   printf("7) Valores de Vetor2 contidos em Vetor1 = %d\n"),
              contidos(v1,4,v2,4);
    maior_menor(v2,4, &maior, &menor);
    printf ("Extra) Maior = %d e Menor = %d\n", maior, menor);



srand(time(NULL));
char opc;
int numero=rand() % 100;
system("cls");
while (opc!='3'){
				 printf("\n 1- MEGA SENA\n");
				 printf(" 2- GANHADORES\n");
				 printf(" 3- SAIR");
				 printf ("\n\nDIGITE SUA OPCAO: ");
				 scanf("%c",&opc);
				 if (opc=='1'){
								printf ("\n\t\t******SORTEIO DA MEGA SENA*******\n\n\n");
								printf("  PRIMEIRO NUMERO = %i \n", numero);
								numero=rand() % 100;
								printf("  SEGUNDO  NUMERO = %i \n", numero);
								numero=rand() % 100;
								printf("  TERCEIRO NUMERO = %i \n", numero);
								numero=rand() % 100;
								printf("  QUARTO   NUMERO = %i \n", numero);
								numero=rand() % 100;
								printf("  QUINTO   NUMERO = %i \n", numero);
				numero=rand() % 100;
								printf("  SEXTO   NUMERO =  %i \n", numero);
								getch();
								}
				 if (opc=='2'){
							   printf("\n\n	quitZAUMMM");
							   scanf("%*c");
							   }
				 }





    return 0;
}

