#include <stdio.h>
#include <stdlib.h>

struct ponto{
    int x;
    int y;
};

void main()
{
    struct ponto p;
    struct ponto *pP;

    p.x = 7;
    p.y = 9;

    pP = &p;

    printf("%d %d", (*pP).x, (*pP).y);
}
