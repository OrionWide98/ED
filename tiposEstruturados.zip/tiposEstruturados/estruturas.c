#include <stdio.h>
#include <stdlib.h>

struct ponto
{
    float x;
    float y;
};

void main()
{
    struct ponto a;
    a.x = 5;
    a.y = 4;
    printf("%.2f, %.2f",a.x, a.y);
}
