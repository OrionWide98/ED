#include <stdio.h>
#include <stdlib.h>

void limpaAmbiente(int **m, int l, int c)
{
    for(int linha=0;linha<l;linha++)
    {
        for(int coluna=0;coluna<c;coluna++)
        {
            m[linha][coluna] = 0;
        }
    }
}

void imprimeAmbiente(int **m, int l, int c, int nf)
{
    for(int linha=0;linha<l;linha++)
    {
        nf?printf("%03d) ", (linha+1)):NULL;
        for(int coluna=0;coluna<c;coluna++)
        {
            printf("%d | ", m[linha][coluna]);
        }
        printf("\n");
    }
}

int reserva(int **m, int f, int p)
{
    if(m[f-1][p-1] == 0)
    {
        m[f-1][p-1] = 1;
        return 1;
    }
    return 0;
}

int main()
{
    FILE * fReserva;
    int fileiras, poltronas;
    int **ambiente;
    char linha[1024];
    int fila, poltrona;
    char *tok;
    char delim[] = ";";
    int v;
    int qualFila;
    int qualPoltrona;

    // abrir o arquivo
    fReserva = fopen("D:\\2019\\ED\\Reserva\\SalaAloisio.csv", "rt");
    if(fReserva == NULL)
    {
        printf("Falha ao abrir o arquivo de dados!\n\n");
        exit(-1);
    }

    fscanf(fReserva, "%d;%d;", &fileiras, &poltronas);

    printf("Fileiras: %d\n", fileiras);
    printf("Poltronas: %d\n\n", poltronas);

    // aloca matriz ambiente
    ambiente = (int **) malloc(fileiras * sizeof(int *));
    if(ambiente==NULL)
    {
        printf("Falha ao alocar matriz de dados!\n\n");
        exit(-1);
    }

    for(int i=0;i<fileiras;i++)
    {
        int * vLinha;
        vLinha = (int *) malloc(poltronas * sizeof(int));
        if(ambiente==NULL)
        {
            printf("Falha ao alocar matriz de dados!\n\n");
            exit(-1);
        }
        ambiente[i] = vLinha;
    }

    limpaAmbiente(ambiente, fileiras, poltronas);

    fila = 0;
    fgets(linha, 1024, fReserva);
    while((fgets(linha,1024,fReserva)) != NULL)
    {
        poltrona=0;
        //
        tok = strtok(linha, delim);
        while(tok != NULL)
        {
            //converte para inteiro
            v = atoi(tok);
            ambiente[fila][poltrona] = v;
            tok = strtok(NULL, delim);
            poltrona++;
        }
        fila++;
    }

    do
    {
        system("cls");
        printf("Fila (0 termina): ");
        scanf("%d", &qualFila);
        if(qualFila<1) break;
        printf("Poltrona: ");
        scanf("%d", &qualPoltrona);
        if(reserva(ambiente,qualFila, qualPoltrona))
        {
            printf("Reserva realizada com sucesso!\n\n");
        }
        else
        {
            printf("Posicao invalida ou indisponivel!\n\n");
        }
        system("pause");
    } while(1);

    imprimeAmbiente(ambiente, fileiras, poltronas, 1);

    fclose(fReserva);

    return 0;
}
