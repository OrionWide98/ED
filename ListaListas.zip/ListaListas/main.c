#include <stdio.h>
#include <stdlib.h>
#include "funcoes.c"

int main(){

    return 0;
}
