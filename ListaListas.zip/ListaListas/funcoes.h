#ifndef FUNCOES_H_INCLUDED
#define FUNCOES_H_INCLUDED
typedef struct lista{
    int info;
    struct lista* proximo;
};

struct lista * separa(struct lista * l, int n);
struct lista* concatena (struct lista* l1, struct lista* l2);
struct lista* constroi (int n, int* v);
struct lista* retira_prefixo (struct lista* l, int n);

#endif // FUNCOES_H_INCLUDED
