#include "funcoes.h"

struct lista * separa(struct lista * l, int n){
    struct lista * l2;

    struct lista * aponta;
    for(aponta=l;aponta!=NULL;aponta= aponta->proximo){
        if(aponta->info == n){
            l2 = aponta->proximo;
            aponta->proximo = NULL;
        }
    }
    return l2;
}

struct lista* concatena (struct lista* l1, struct lista* l2){
    struct lista * temp;

    for(temp=l1;temp!=NULL;temp=temp->proximo){
        if(temp->proximo == NULL){
            temp->proximo = l2;
        }
    }
    return l1;
}

struct lista* constroi(int n, int* v){
    struct lista* novo;
    struct lista* aponta;

    for(int k= 0;k< n;k++){
        novo = (struct lista*) malloc(sizeof(struct lista));
        novo->info = v[k];
        novo->proximo = aponta;

        aponta = novo;
    }
    return aponta;
}

struct lista* retira (struct lista* l, int v) {
    struct lista* ant = NULL; /* ponteiro para elemento anterior */
    struct lista* p = l; /* ponteiro para percorrer a lista*/
    /* procura elemento na lista, guardando anterior */
    while (p != NULL && p->info != v) {
    ant = p;
    p = p->proximo;
    }
    /* verifica se achou elemento */
    if (p == NULL)
    return NULL; /* n�o achou: retorna lista original */
    /* retira elemento */
    if (ant == NULL) {
    /* retira elemento do inicio */
    l = p->proximo;
    }
    else {
    /* retira elemento do meio da lista */
    ant->proximo = p->proximo;
    }
    free(p);
    return l;
}

struct lista* retira_prefixo (struct lista* l, int n){
    if(n<0){
        printf("Numero precisa ser negativo!");
    }
    else{
        for(int k=0;k<n;k++){
            if(l == NULL){
                return l;
            }
            l = retira(l, l->info);
        }
    }
    return l;
}
