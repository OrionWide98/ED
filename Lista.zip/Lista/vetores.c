/*
* Francisco Eduardo Pereira Sousa Silva  RA: 18464
* Clayton Gabriel Lorizolla RA: 18457
*/

int escalar (int *vetor1, int *vetor2, int nElementos){
    int soma = 0;
    for(int i=0;i<nElementos;i++){
        soma += vetor1[i] * vetor2[i];
    }
    return soma;
}

int todosDiferentes(int *vetor, int nElementos){
    int t = 1;
    int v[nElementos];
    for(int a=0;a<nElementos;a++){
        v[a] = vetor[a];
    }

    for(int i=0;i<nElementos;i++){
       for(int c=0;c<nElementos;c++){
            if(vetor[c] == v[i]){
                    t = 0;
            }
       }
    }
    return t;
}

void rotaciona (int *vetor, int nElementos){
    int v[nElementos];
    int a = nElementos;
    for(int i=0;i<nElementos;i++){
        v[a-1] = vetor[i];
        a--;
    }
    printf("\n%d %d\n", vetor[0],v[4]);
}

int contaValores(int *vetor, int nElemento, int limInf, int limSup){
    int t=0;
    if(limInf>limSup){
        printf("Erro");
    }
    else {
        for(int i=0;i<nElemento;i++){
            if((vetor[i]>=limInf)&&(vetor[i]<=limSup)){
                t++;
            }
        }
    }
    return t;
}

int menorElemento(int *vetor, int nElementos){
    int m;
    int menor=0;
    for(int i=0;i<nElementos;i++){
        if(i==0){
            menor = vetor[i];
            m=i;
        } else{
            if(vetor[i]<menor){
                menor = vetor[i];
                m=i;
            }
        }
    }
    return m+1;
}

int maiorElemento(int *vetor, int nElementos){
    int m;
    int maior=0;
    for(int i=0;i<nElementos;i++){
        if(i==0){
            maior = vetor[i];
            m=i;
        } else{
            if(vetor[i]>maior){
                maior = vetor[i];
                m=i;
            }
        }
    }
    return m+1;
}

int contidos(int *v1, int nElementos1, int *v2, int nElementos2){
    int c=0;
    for(int i=0;i<nElementos1;i++){
        for(int a=0;a<nElementos2;a++){
            if(v1[i] == v2[a]){
                c++;
            }
        }
    }
    return c;
}
