#include <stdio.h>
#include <stdlib.h>
#include "vetores.h"

int main()
{

    int x[5]={1,1,1,1,1};
    int y[5];
    int r;
/*
    for(int c=0;c<5;c++){
        printf("Valor de x:");
        scanf("%d",&x[c]);
        printf("Valor de y:");
        scanf("%d",&y[c]);
    }
    int r = escalar(x,y,5);
    printf("%d\n\n\n",r);
    for(int c=0;c<5;c++){
        printf("Valor de x:");
        scanf("%d",&x[c]);
    }
*/

    r = todosDiferentes(x,5);
    printf("%d",r);
/*
    rotaciona(x,5);

    r=contaValores(x,5,1,6);
    printf("%d",r);

    r=menorElemento(x,5);
    printf("\n%d",r);

    r=maiorElemento(x,5);
    printf("\n%d",r);

    r=contidos(x,5,y,5);*/
}
